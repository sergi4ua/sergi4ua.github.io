#ifndef _WRITE_H_
#define _WRITE_H_

#include "cel.h"

int write_file(char *, unsigned char *, unsigned long int);
int write_cel_file(CEL_FILE *, char *);

#endif /* _WRITE_H_ */
