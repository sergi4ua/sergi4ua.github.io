#ifndef _DT1_H_
#define _DT1_H_

typedef char BYTE;
typedef unsigned char UBYTE;
typedef short int WORD;
typedef short int UWORD;
typedef long int DWORD;
typedef long int UDWORD;

#define dt1_head_size 276
#define block_size     96
#define sub_tile_size  20

typedef struct {
   WORD xpos;
   WORD ypos;
   int  xgrid;
   int  ygrid;
   WORD format;
   long data_length;
   long data_offset;
} SUB_TILE_S;

typedef struct {
   long  direction;
   WORD  roof_y;
   UBYTE tile_sound;
   UBYTE animated;
   long  ysize;
   long  xsize;
   long  orientation;
   long  main_index;
   long  sub_index;
   long  frame;
   long  unknown;
   int   sub_tiles_flags[25];
   long  tiles_ptr;
   long  tiles_length;
   long  tiles_number;
} BLOCK_S;

#endif /* _DT1_H_ */
