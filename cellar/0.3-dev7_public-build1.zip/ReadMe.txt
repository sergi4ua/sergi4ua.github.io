Syobon Action X is currently under active development.
Please report any bugs or suggestions at the GameJolt page and at GitHub Issue Tracker.

Controls:
Game:
Up - Jump
Left,Right - Move
Insert - switch to Level Editor

Editor:
T - next tile
R - previous tile
0 - reset view
1 - blocks
2 - backgrounds
3 - "bonuses"
F1 - main menu

Website:
sergi4ua.github.io

GitHub repository:
https://github.com/sergi4ua/SyobonActionX

Copyright:
This game was created by Sergi4UA.
The original games were created by Chiku.
http://www.geocities.jp/z_gundam_tanosii/Misc/syobon_action_description.html
