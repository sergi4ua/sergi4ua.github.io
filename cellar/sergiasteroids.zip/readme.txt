Congrats! You found my secret game!
This is a simple "edit" of raylib's asteroids example (added score, music and higher asteroid spawn)
Source code is included :)

www.raylib.com
https://sergi4ua.github.io