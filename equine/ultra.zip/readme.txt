Diablo Ultra v1.2

By Rincewind[GdL]


------------------------------------------------------------------------
Vorwort
------------------------------------------------------------------------

Noch ein Mod ? *g�hn* ...
Ja, noch ein Mod, aber dieser geht von folgenden Annahmen aus:

- Diablo ist viel zu einfach
- es sind MONSTER, gegen die man da unten k�mpft
- Spezialisierung ist wichtig
- 2-h�ndiges K�mpfen sollten eine ECHTE Alternative sein
- Uniques in Diablo sind M�ll
- negative Pr�/Suffixe sind witzlos
- Es gibt viel zu wenig Bier in Diablo :-)

Also hab ich mich drangesetzt, und in wochenlanger Arbeit s�mtliche Pr�/Suffixe umgestrickt, s�mtlichen Monstern einen Schnellkurs im Fitnesstudio verordnet, die Magie modifiziert, die Charklassen ver�ndert und das ganze ausbalanciert.
Das Balancing war dann auch der Hammer. Nat�rlich richtet sich nun das ganze Mod nach meiner Art zu spielen. Manchen erscheint es als unspielbar schwer, andere haben ne Menge Spa� daran. Das es zu einfach sei, hat mir noch keiner gesagt *g*
Denn Hell/Hell-Run in 15 Minuten kann man hier nun getrost vergessen. Wer mit dem Warrior einfach losrennt, kann sich auch gleich in sein Schwert schmei�en.
Was ich damit sagen will ist: wer nicht vorsichtig und umsichtig spielt, wird an diesem Mod keinen Spa� haben.
Ich wei� nicht, wie sich das Mod im Single-Player verh�lt, aber wer spielt schon Single-Player ?

Nochwas. Es gibt inzwischen eine Menge Mods. Jedes hat so seine Eigenarten. VK z.B. haben (nicht zuletzt durch die Hilfe vieler Zocker) das wohl technisch ausgereifteste Mod. Ultra ist wohl bisher das schwierigste, obwohl Abysmal in die selbe Richtung geht. Mir wird oft die Frage gestellt, warum ich nicht dieses oder jenes Feature aus diesem oder jenem Mod einbaue. Die Antwort ist recht simpel, ich kann es (oft) nicht *g*
Ich bin nicht in der Lage, den Quellcode der Exe aufzuschl�sseln, und SC-Imunit�t einzubauen. Ich musste mich beim erstellen dieses Mods an das halten, was ich konnte oder rausgefunden habe. Gut m�glich, das sp�tere Ultra-Versionen solche Features enthalten, denn man lernt ja nie aus :-)
Falls sich jemand berufen f�hlt, mir dabei zu helfen --> rince@gdl-home.de

------------------------------------------------------------------------
Installation
------------------------------------------------------------------------

Einfach die ultra.exe in den vorhandenen Diablo-Ordner der Version 1.07 kopieren und dann die Datei ultra.exe zum Spielen starten.
Die Chars werden als gdlsin_X.drv (Singleplayer) und als gdldia_x.drv (Multiplayer) im Windows-Dir gesaved

------------------------------------------------------------------------
Multiplayer im Internet
------------------------------------------------------------------------

Multiplayer (das wichtigste *g*) ist auch �bers Internet kostenfrei m�glich!

Einfach zu www.cmga.net surfen, registrieren und den "Misson Connector" (MC) downloaden.
Zum Spiele �bers Internet:
				- MC starten
				- Spiele/Konfigurieren/Eigenes Spiel hinzuf�gen
                  			- ultra.exe einstellen
				- das Spiel Diablo Ultra nennen
				- best�tigen
				- starten
				- in Diablo Ultra auf Multiplayer/Netzwerk gehen
				- viel Spa� mit bis zu Vier Spielern!
Es gibt eine neue Version bei CMGA, mit dre es anscheinend ein paar Probleme gibt...mal abwarten...

Eine weitere M�glichkeit ist es, per FSGS (http://www.fsgs.com/) einen eigenen lokalen B.net Server aufzumachen,
und auf diesem zu spielen. Mit 4 Personen ist dies mei�t lagfrei m�glich, solange der Server
ISDN hat *g*.
Um den Server joinen zu k�nnen, tr�gt man in der Registry im Schl�ssel
Hkey_lokal_machine/software/battlenet/configuration/serverlist
die IP des lokalen Servers ein, startet Ultra und joint das Bnet. Die IP findet man raus, indem man z.B. Winipcfg.exe startet (is bei Win dabei, einfach suchen). Wenn man den Server startet, zeigt er die IP aber auch an :-) Den Server zu konfigurieren ist nicht wieter wild und selbsterkl�rend.
Derjenige, der den Server hostet, mu� sich allerdings genauso einloggen, wie alle anderen, also seine eigene IP im Server-Schl�ssel angeben, und dann das Bnet joinen :-)

Die 3 M�glichkeit ist das Spielen �bers B-Net selbst. Dazu bracht man Dhack und das DAT-File des Mods.
Dhack bekommt man z.B. auf Henjos Diablo-Page (http://come.to/henjo).
Um im Bnet zu spielen:
-Diablo (original) starten
-Bnet joinen
-Sobald man im Channel ist Alt-Tab und Dhack starten
-ultra.dat laden und aktivieren
-Alt-Tab zur�ck ins Bnet, und "verlassen" anklicken
-Direkt wieder Joinen, nun mit dem Mod-Char (eventuell neuen Account anlegen)
-Einfach so tun, als sei nix passiert *g*

Achja, Spiele mit anderen Diablo-Versionen f�hren zum Absturz, also immer sch�n die Games kennzeichnen !
Als Kennzeichnung hat sich "name~rm" etabliert.


------------------------------------------------------------------------
�nderungen
------------------------------------------------------------------------

Es blieb nahezu nichts beim Alten. Einige Namen sind nicht ge�ndert worden, daf�r aber die Eigenschaften. Wichtig zu wissen: Es gibt keine Zweih�nder-Schwerter oder Kn�ppel mehr. Maul, Great Sword und Barbarian Sword (ehemals 2-Handed Sword) sind jetzt Einh�nder. Wer Zweih�nder will, greife zu Axt, Stab oder Bogen. Es gibt auch einige neue Zauberspr�che, die leider nicht im Spellbook vermerkt werden.
Ich werde keine Tabellen ver�ffentlichen, welches Monster exakt wieviele HP�s hat; wer sich berufen f�hlt, kann ja einen Katalog anlegen :-).

Charklassen:
Krieger: Str 30/250, Mag 0/0,    Dex 20/80,  Vit 35/130
Diebin:  Str 15/40,  Mag 15/80,  Dex 35/250, Vit 20/90
Magier   Str 10/60,  Mag 45/250, Dex 10/100, Vit 20/50

Jetzt lernbare Spells:
Identify, Infravision, Resurect, Apocalypse(verursacht auch ein Phasing)

Neue Spells:
Overkill: Apo, Fireball und CL auf einen Schlag
Tripple: Apo, Firewall und Guardian
Protect: Etheralize (eine Art Shield) und MS
Save Shot: Fireball und Sc
Deathword: Lightning und Firebold

Items:
Maul, Great Sword und Barbarian Sword (ehemals Two-handed Sword) sind nun Einh�nder

Neue Items:
Not-Axt: ersetzt die Broad Axe
Rubin: bringt bei Rechtsklick +3 auf alles Permanent (einmalig)

Unique Items:
Lasst euch �berraschen...


------------------------------------------------------------------------
Bekannte Probleme
------------------------------------------------------------------------

-Nicht alle neuen Spells sind im Spellbook vermerkt
-Doppelte Itemdrops/Golddrops k�nnen vorkommen
-Die HP der Hell-Monster werden nicht korekkt berechnet


------------------------------------------------------------------------
Danksagungen
------------------------------------------------------------------------

- Dem Autor des Modmakers, mit welchem ich einen Gro�teil der Arbeit gemacht habe.
  Seine E-Mail ist: "vrahvinv@bellsouth.net"

- Den Betatestern: Aufklaerer[KDH], Jezira[GdL], LordofCrow[GdL], Garilon[GdL]
  Elite24[GdL] und Starchild[GdL].  Speziell Aufklaerer[KDH] hat mit mir viele Stunden
  in den Dungeons verbracht.

- Tanis{GM�s} f�r Hilfe beim Bugfixen und beim versetzen von Adria/Wirt

- AZRAEL f�r das �bersetzen der Docs

- Allen, die mit Vorschl�gen/Ideen zum Mod beigetragen haben.



------------------------------------------------------------------------
Contact
------------------------------------------------------------------------

Bei Fragen, Anregungen, Bugreports usw: rince@gdl-home.de
oder im Forum auf http://www.gdl-home.de


------------------------------------------------------------------------


alsdann...


Rincewind[GdL]
