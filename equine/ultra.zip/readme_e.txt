Diablo Ultra v1.2

By Rincewind[GdL]


------------------------------------------------------------------------
Preface
------------------------------------------------------------------------

A new mod ? *yawn* ...
Yes, a new mod, but i decided making it because i noticed some things:

- diablo is way too easy
- you fight against MONSTERS down there
- specialization is important
- fighting two-handed should be a REAL alternative
- Uniques in diablo were crap
- cursed items are senseless
- There is far too little beer in diablo :-)

So i sat down, changed all pre-/suffixes, out all monsters into a
fitness center, didn't see daylight for weeks, modified magic, revised
character classes, and, last but not least, balanced the whole thing.
Balancing was damn hard, i can tell. Of course now the mod is like I
prefer playing diablo, some might find it impossible to play while
others might have a lot of fun with it. No one found it too easy yet ;))
Forget doing hell/hell in 15 minutes. If you think warrior is run down
and slay you might as well eat your sword.
What i wanted to say is: If you're not playing carefully, playing this
mod (or lying on the ground ;)) won't be much fun.
I don't know how the mod plays in single player but who plays single?

There are many mods today, and they all have their style. VK for
instance have (not the least because of the support from the players)
the most advanced mod. Ultra is the hardest (at least to my knowledge)
but abysmal is not easy either.
I am often asked why I do not implement this or that feature from
another mod. Simple answer: Often i simply don't know how to do it.
I can't decode the exe to add SC immunity, I don't know how to alter
the townspeoples' positions. I had to use what i already knew or what
I found out while making this mod.
If anyone wants to help me making this mod even better --> rince@gdl-home.de


------------------------------------------------------------------------
Installation
------------------------------------------------------------------------

Simply copy the ultra.exe into your diablo (v1.07) folder and use ultra.exe instead of diablo.exe to start the game.
Character save files are gdlsin_X.drv (Singleplayer) and gdldia_x.drv (Multiplayer) in your windows directory.


------------------------------------------------------------------------
Multiplayer on the Internet
------------------------------------------------------------------------

Of course you can play multiplayer (free) over internet too.

Simply surf to www.cmga.net, register and d/l "Misson Connector" (MC).
How 2 play using MC:

				- Start MC
				- Spiele/Konfigurieren/Eigenes Spiel hinzuf�gen
                  			- add ultra.exe
				- Name it Diablo Ultra
				- OK
				- start
				- in Diablo Ultra go to Multiplayer/Network
				- Have fun with up to four players!
With the new Version of CMGA there are some problems...we�ll have to wait and see...

OR you open you own battle.net server using FSGS (http://www.fsgs.com/).
If the server has ISDN or faster ( a T1 line would be optimal ;)) it
should be lag free with up to four players (enough for one game)
To youn the server edit your registry using regedit in your windows
directory: Add the IP of the FSGS b.net server to
Hkey_loca_machine/software/battlenet/configuration/serverlist,
start diablo ultra and join battle.net.
You can check the IP using winipcfg.exe (comes with windows), but when
starting the server it shows the ip so you don't need winipcfg.
configuring the server is not very complicated and quite self-explanatory.
The one hosting the server must log in as all others have to.

OK, now the third, best, and almost easiest method:
Playing over blizzard's battle.net!
In order to play over battle.net you must use the .dat version of the mod
and dhack (available at Henjo's diablo page
http://come.to/henjo).
- start Diablo (original .exe!)
- go to multiplayer
- Alt-tab out of the game and start dhack
- Load ultra.dat
- return to Diablo (via Alt-tab or by pressing on "Diablo" on the task bar
- Join battle.net
- Have fun!


Don't play with other diablo versions or dats if you're running diablo
ultra or the game will crash!
Diablo Ultra players normally have a ~rm at the end of their names.


------------------------------------------------------------------------
Changes from standard Diablo
------------------------------------------------------------------------

Almost everything has changed. Some names are still the same, but
properties have changed.
Important to know: There are no two-handed swords or clubs in Diablo Ultra.
Maul, Great Sword and Barbarian Sword (ex 2-handed sword) are one-handed now.
If you want to play two-handed use axes, staves, or bows.
I also added a few spells, which unfortunately not appear in your spellbook
(but in the speedbook, so you can still use them):

-Overkill: Apo, Fireball and CL in one spell
-Tripple: Apo, Firewall and Guardian
-Protect: Etheralize (a protecting spell) and MS
-Save Shot: Fireball and SC
-deatword: Lightning and Firebold

Now learnable:
Identify, Infravision, Resurect,
Apocalypse(casting apo will cause a phasing too)

I will not develop any tables with monster HPs or something like that;
if you want to do one you have the permission to do so ;)

Char classes:
Warrior: Str 30/250, Mag 0/0,    Dex 20/80,  Vit 35/130
Rogue:  Str 15/40,  Mag 15/80,  Dex 35/250, Vit 20/90
Sorceror:   Str 10/60,  Mag 45/250, Dex 10/100, Vit 20/50

New Items:
Not-Axt: replaces Broad Axe
Rubin: elixir that brings +3 to all


Unique Items:
Now i don't want to spoil all the fun... come in and find out ;)


------------------------------------------------------------------------
Known problems (ignore them ;)
------------------------------------------------------------------------

-Not all new spells show up in your spellbook
-double Itemdrops/Golddrops may appear
-HP of hell monsters are not as high as displayed


------------------------------------------------------------------------
Thanx to
------------------------------------------------------------------------

- The author of the Modmaker with which i made a large amount of the mod
  His E-Mail: "vrahvinv@bellsouth.net"

- The betatesters: Aufklaerer[KDH], Jezira[GdL], LordofCrow[GdL], Garilon[GdL]
  Elite24[GdL] and Starchild[GdL]. Special thanx to Aufklaerer[KDH] for he
  spent many hours with me in the dungeons testing and playing.

- Tanis{GM�s} for Bugfixing-Help and for explaining to me how to move Adria/Wirt

- AZRAEL for translating the Docs

- All people who helped me with suggestions, constructive critic, or beer ;))



------------------------------------------------------------------------
Contact
------------------------------------------------------------------------

Questions, suggestions, bug reports etc: rince@gdl-home.de
or on our Forum at http://www.gdl-home.de (german)


------------------------------------------------------------------------


fare thee well...


Rincewind[GdL]
