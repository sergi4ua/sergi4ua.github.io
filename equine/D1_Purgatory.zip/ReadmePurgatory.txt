Purgatory

              Diabolic Hellfire Modification

   1.Playing Purgatory 
        a.Contents 
        b.System Requirements 
        c.Installation 
        d.Running Purgatory 
   2.Troubleshooting 
        a.Known Problems 
        b.FAQ 
        c.Updates 
        d.Revision History 
   3.Information 
        a.Purgatory 
        b.Contact 
        c.Credits 
        d.Legal 

1. Playing Purgatory

   a. Contents

   The following files are included in the Purgatory self-extracting Zip archive
   (PurgatoryZip.exe): 

     DATAPURG.TXT 
     Purgatory.exe 
     purgatory.ini 
     purgatui.dll 
     Readme.html 
     ReadmePurgatory.txt 
     special.txt 

   The archive can also be opened with a standard Zip program. 

   b. System Requirements

   Purgatory requires Hellfire v1.01. The patch can be downloaded from Sierra. 

   c. Installation

   Extract all files to your Hellfire directory. 

   d. Running Purgatory

   Double-click on Purgatory.exe. 

2. Troubleshooting

   a. Known Problems

   Slain Hero bug
   The game freezes if the Slain Hero is touched. 

   Multi Player and the hidden characters are disabled
   This problem is caused by using a desktop shortcut that was created with the "send
   to" command. To avoid it, create a shortcut without using the "send to" command. 

   b. FAQ

   How do I transfer my Diablo or Hellfire characters to Purgatory?
   Just copy and rename the characters you wish to transfer. Single Player characters
   have to be renamed from single_#.sv (Diablo) or single_#.hsv (Hellfire) to
   single_#.psv; Diablo characters must be moved to the Hellfire directory. Multi
   Player characters, located in the Windows directory, have to be renamed from
   dlinfo_#.drv (Diablo) or hrinfo_#.drv (Hellfire) to purgmp_#.drv.
   # denotes a number from 0 to 9. 

   I get the error message "storm.dll is missing".
   Copy the file from your Hellfire CD to your Hellfire directory and replace the old
   one. The patch does not update this file. 

   How do I create my own mod?
   Check out the links section on my Purgatory Website, some of the listed sites offer
   information on the creation of Diablo/Hellfire mods. 

   c. Updates

   Purgatory v0.40 is the final version and will not be updated. 

   d. Revision History

   0.10 
        Internal test version 
   0.20 
        First public version including Crystalion's bugfixes 
   0.21 
        Easier monsters in the Cathedral 
   P3 
        Preview version for 0.30 with many problems 
   0.40 Beta 1 
        Completely new build but only the Cathedral is playable 
   0.40 Beta 2 
        Catacombs are playable 
   0.40 Beta 3 
        Caves are playable 
   0.40 Beta 4 
        Hive is playable 
   0.40 Beta 5 
        Crypt is playable 
   0.40 Beta 6/7 
        Hell is playable and minor changes 
   0.40 
        Final changes 

3. Information

   a. Purgatory

   For Purgatory data see the file DATAPURG.TXT or visit the Purgatory Website. 

   b. Contact

   You can e-mail me at loklorn@mayn.de. 

   c. Credits

   Purgatory created by J.M. Hoefelein 

   Thanks to all the peeple who helped and encouraged me! 

   d. Legal

   Download and use Purgatory entirely at your own risk.
   Diablo � Blizzard Entertainment
   Hellfire � Sierra 

   Purgatory Readme 7.11.1999 

