The Dark version 5.4 Revision A (June 29, 2009) by Zamal and Zenda 
--------------------------------------------------------------------------------------------------------------------
Introduction and acknowledgement


This Hellfire modification has been started in November 1998. It is based upon the famous HFMOD V2 from Varaya and Khan, dated September 2 1998.

The reasons we used Varaya and Khan's version to work upon are that it was very well balanced and had a lot of bugfixes and nice enhancements in it. We saw no need to redo all this, mostly because we would not have able to do it at that time.

You will be able to play SinglePlayer as well as MultiPlayer. See 'Notes on SinglePlayer' if you like the quests, or plan to do single player games for other reasons. All other information in this file is for both MultiPlayer and SinglePlayer, unless indicated otherwise.

This game has been made possible with the help of many people. Ogden will tell you about them when you first enter a game.

Special thanks go to ArthurDent, for his suggestions, feedback, playtesting, making the Guide, being a great co-op partner, and taking care of all image and sound related things.
--------------------------------------------------------------------------------------------------------------------
Features


There are too many features to list here. Please check the website (where you can find The Dark Guide) and forum at HTTP://www.TheDark5.com
--------------------------------------------------------------------------------------------------------------------
Installation and Playing


To be able to play this mod, you must have access to the Diablo CD and have Hellfire installed on your computer.

Place all files belonging to this modification, which are listed blow, in your Hellfire folder or, preferrably, in a copy of your Hellfire folder.

HLFDRK54A.EXE         Main program
THEDARKUI.DLL         Menu program
TD54.MPQ              Resource file
THEDARKREADME.TXT     This Readme

Use the program with its original filename, which is HLFDRK54A.EXE for this version. This will help avoiding MultiPlayer games with other Hellfire versions over KALI.

There is no longer need for a command file, and any parameters in such a file will not be used.

Savegame files for MultiPlayer no longer depend on Computer Name in this version. It is required that you start new characters, for SinglePlayer as well as MultiPlayer games.  

Start the game by running HLFDRK54A.EXE or a shortcut to it, and remember that it will be much harder than regular Hellfire.

We strongly discourage the use of other hacks, like PATCHELP. Because so much is changed chances are very large that the game will crash.

If you place the file DOOM.SMK in a subdirectory GENDATA, the intro of the game will be expanded with sound.

You can customize your hotkeyed MultiPlayer messages (F9-F12) by creating a file TheDark.ini in your playing directory. It must be the same format as Hellfire.ini from Hellfire or Diablo.ini from Diablo.
--------------------------------------------------------------------------------------------------------------------
General Notes


Only characters below level 30 can enter Normal Mode games, and only those of level 20 or higher can enter Nightmare and Hellmode.

Nest and Abyss areas these areas can be entered from town by clicking the correct entrance. For the Abyss this is the black grave to the right of Tristram's church. For the Nest you have to blow up its entrance first. In MultiPlayer the farmer's Rune bomb must only be used by the game creator. As in Hellfire, you can only enter the Abyss in SinglePlayer with the Cathedral Map. In this mod you can find it on the last level of Hell, not in the Nest.

Some SinglePlayer quests are disabled, for various reasons. Others are placed one or more levels deeper, and sometimes use other monsters.

Although the Blood Stones from the Valor quest appear to be the same as the Blood Stones you can find, they are the only ones that can be used in the quest.
--------------------------------------------------------------------------------------------------------------------
Do NOT contact BLIZZARD or SIERRA for questions or remarks about this mod. They do NOT support it. SIERRA does not support MultiPlayer in Hellfire, also.

The creators of this modification cannot be held responsible for any damage that comes from using this software, but you don't have to worry very much: we use it ourselves very often ...