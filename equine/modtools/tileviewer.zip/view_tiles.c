/*
Viewer for Diablo/Hellfire tiles
Original source is from Paul Siramy and is for Diablo 2
But well written code is easy to modify :)
You may have a look at http://paul.siramy.free.fr/
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <allegro.h>
#include "mpq_lib.h"

/* Element of town.cel or towns.cel 
   Warning : encoding varies from file to file */
typedef struct {
   unsigned long int size;
   unsigned char *data;
} CEL;

typedef struct {
   unsigned char *data;
   unsigned long int nb;
   CEL *frame;
} CEL_FILE;

typedef struct {
   int nb;
   unsigned short int *data;
} MIN;

typedef struct {
   int nb;
   unsigned short int *data;
} AMP;

typedef struct {
   int nb;
   unsigned char *data;
} SOL;

typedef struct {
   int nb;
   unsigned short int (*data)[4];
} TIL;

typedef struct {
   int min_size;
   CEL_FILE *cel;
   CEL_FILE *scel;
   MIN *min;
   SOL *sol;
   AMP *amp;
   TIL *til;
} MAP;

typedef enum {GC_060, GC_062, GC_064, GC_066, GC_068,
              GC_070, GC_072, GC_074, GC_076, GC_078,
              GC_080, GC_082, GC_084, GC_086, GC_088,
              GC_090, GC_092, GC_094, GC_096, GC_098,
              GC_100,
              GC_110, GC_120, GC_130, GC_140, GC_150,
              GC_160, GC_170, GC_180, GC_190, GC_200,
              GC_210, GC_220, GC_230, GC_240, GC_250,
              GC_260, GC_270, GC_280, GC_290, GC_300,
              GC_MAX} GC_ENUM;

char gamma_str[GC_MAX][5] = {
           {"0.60"}, {"0.62"}, {"0.64"}, {"0.66"}, {"0.68"},
           {"0.70"}, {"0.72"}, {"0.74"}, {"0.76"}, {"0.78"},
           {"0.80"}, {"0.82"}, {"0.84"}, {"0.86"}, {"0.88"},
           {"0.90"}, {"0.92"}, {"0.94"}, {"0.96"}, {"0.98"},
           {"1.00"},
           {"1.10"}, {"1.20"}, {"1.30"}, {"1.40"}, {"1.50"},
           {"1.60"}, {"1.70"}, {"1.80"}, {"1.90"}, {"2.00"},
           {"2.10"}, {"2.20"}, {"2.30"}, {"2.40"}, {"2.50"},
           {"2.60"}, {"2.70"}, {"2.80"}, {"2.90"}, {"3.00"}
        };

char path [7][100] = {
                 {"levels\\towndata"},
                 {"levels\\l1data"},
                 {"levels\\l2data"},
                 {"levels\\l3data"},
                 {"levels\\l4data"},
                 {"nlevels\\l5data"},
                 {"nlevels\\l6data"}
              };
char palname[7][6][80] = {
                 { "town.pal", "town.pal", "town.pal", "ltpalg.pal", "ltpalg.pal", "ltpalg.pal" },
                 { "l1_1.pal", "l1_2.pal", "l1_3.pal", "l1_4.pal", "l1_5.pal", "l1_5.pal" },
                 { "l2_1.pal", "l2_2.pal", "l2_3.pal", "l2_4.pal", "l2_5.pal", "l2_5.pal" },
                 { "l3_1.pal", "l3_2.pal", "l3_3.pal", "l3_4.pal", "l3pfoul.pal", "l3pwater.pal" },
                 { "l4_1.pal", "l4_2.pal", "l4_3.pal", "l4_4.pal", "l4_4.pal", "l4_4.pal" },
                 { "l5base.pal", "l5base.pal", "l5base.pal", "l5base.pal", "l5base.pal", "l5base.pal" },
                 { "l6base1.pal", "l6base2.pal", "l6base3.pal", "l6base4.pal", "l6base5.pal", "l6base.pal" }
              };
char lvlname [7][10] = {
                 {"town"},
                 {"l1"},
                 {"l2"},
                 {"l3"},
                 {"l4"},
                 {"l5"},
                 {"l6"}
              };

unsigned char cel_image_data[0x400];
unsigned char pal[256][3];
unsigned char gamma_table[GC_MAX][256];
int     cur_gamma = GC_140;
PALETTE the_pal;
MAP glb_map;

MIN *read_min(char *filename, int min_size) {
   MIN *res;
   unsigned char *buff;
   long int size;

   res = (MIN *)malloc(sizeof(MIN));
   if (res == NULL) {
      fprintf(stderr, "Cant alloc %u bytes\n", sizeof(MIN));
      return NULL;
   }
   misc_load_mpq_file(filename, &buff, &size, 0);
   res->data = (unsigned short int *)buff;
   if (res->data == NULL) {
      free(res);
      return NULL;
   }
   if (size % (min_size * 2) != 0) {
      fprintf(stderr, "Unusual %s size, should contain 0x%x sized entries\n", filename, min_size);
      free(res->data);
      free(res);
      return NULL;
   }
   res->nb = size / (min_size * 2);
   return res;
}

void destroy_min(MIN *min) {
   if (min == NULL)
      return;
   if (min->data != NULL) {
      free(min->data);
   }
   free(min);
   return;
}

SOL *read_sol(char *filename) {
   SOL *res;
   long int size;

   res = (SOL *)malloc(sizeof(SOL));
   if (res == NULL) {
      fprintf(stderr, "Cant alloc %u bytes\n", sizeof(SOL));
      return NULL;
   }
   misc_load_mpq_file(filename, &(res->data), &size, 0);
   if (res->data == NULL) {
      free(res);
      return NULL;
   }
   res->nb = size;
   return res;
}

void destroy_sol(SOL *sol) {
   if (sol == NULL)
      return;
   if (sol->data != NULL) {
      free(sol->data);
   }
   free(sol);
   return;
}

TIL *read_til(char *filename) {
   TIL *res;
   long int size;
   unsigned char *buff;

   res = (TIL *)malloc(sizeof(TIL));
   if (res == NULL) {
      fprintf(stderr, "Cant alloc %u bytes\n", sizeof(TIL));
      return NULL;
   }
   misc_load_mpq_file(filename, &buff, &size, 0);
   res->data = (unsigned short int (*)[4])buff;
   if (res->data == NULL) {
      free(res);
      return NULL;
   }
   if (size % 0x8 != 0) {
      fprintf(stderr, "Unusual %s size, should contain 0x8 sized entries\n", filename);
      free(res->data);
      free(res);
      return NULL;
   }
   res->nb = size / 8;
   return res;
}

void destroy_til(TIL *til) {
   if (til == NULL)
      return;
   if (til->data != NULL) {
      free(til->data);
   }
   free(til);
   return;
}

AMP *read_amp(char *filename) {
   AMP *res;
   unsigned char *buff;
   long int size;

   res = (AMP *)malloc(sizeof(AMP));
   if (res == NULL) {
      fprintf(stderr, "Cant alloc %u bytes\n", sizeof(AMP));
      return NULL;
   }
   misc_load_mpq_file(filename, &buff, &size, 0);
   res->data = (unsigned short int *)buff;
   if (res->data == NULL) {
      free(res);
      return NULL;
   }
   res->nb = size / 2;
   return res;
}

void destroy_amp(AMP *amp) {
   if (amp == NULL)
      return;
   if (amp->data != NULL) {
      free(amp->data);
   }
   free(amp);
   return;
}

CEL_FILE *load_cel_file(char *filename) {
   long int size, i;
   CEL_FILE *res;

   res = (CEL_FILE *)malloc(sizeof(CEL_FILE));
   if (res == NULL) {
      fprintf(stderr, "Cant alloc %u bytes for CEL_FILE struct\n", sizeof(CEL_FILE));
      return NULL;
   }
   misc_load_mpq_file(filename, &(res->data), &size, 0);
   if (res->data == NULL) {
      free(res);
      return NULL;
   }
   if (size < 4) {
      fprintf(stderr, "File too short\n");
      free(res->data);
      free(res);
      return NULL;
   }
   res->nb = *((unsigned long int *)res->data);
   res->frame = (CEL *)malloc(res->nb * sizeof(CEL));
   if (res->frame == NULL) {
      fprintf(stderr, "Cant alloc %lu bytes for CEL_FILE\n", res->nb * sizeof(CEL));
      free(res->data);
      free(res);
      return NULL;
   }
   for (i = 0; i < res->nb; ++i) {
      res->frame[i].data = res->data + ((unsigned long int *)res->data)[i + 1];
      res->frame[i].size = ((unsigned long int *)res->data)[i + 2] - ((unsigned long int *)res->data)[i + 1];
   }
   return res;
}

void destroy_cel_file(CEL_FILE *cel_file) {
   if (cel_file == NULL)
      return;
   free(cel_file->frame);
   free(cel_file->data);
   free(cel_file);
   return;
}

char *init_map(int act) {
   int size_of_min[8] = { 16, 10, 10, 10, 16, 10, 10, 16 };
   char tmp[300];

   if ((act <0) || (act > 7))
      return "Nothing !";
   memset(&glb_map, 0, sizeof(glb_map));
   sprintf(tmp, "%s\\%s.cel", path[act], lvlname[act]);
   glb_map.cel = load_cel_file(tmp);
   glb_map.min_size = size_of_min[act];
   sprintf(tmp, "%s\\%s.min", path[act], lvlname[act]);
   glb_map.min = read_min(tmp, glb_map.min_size);
   sprintf(tmp, "%s\\%s.til", path[act], lvlname[act]);
   glb_map.til = read_til(tmp);
   sprintf(tmp, "%s\\%s.sol", path[act], lvlname[act]);
   glb_map.sol = read_sol(tmp);
   sprintf(tmp, "%s\\%s.amp", path[act], lvlname[act]);
   glb_map.amp = read_amp(tmp);
   sprintf(tmp, "%s\\%ss.cel", path[act], lvlname[act]);
   glb_map.scel = load_cel_file(tmp);
   return lvlname[act];
}

void free_map() {
   destroy_til(glb_map.til);
   glb_map.til = NULL;
   destroy_sol(glb_map.sol);
   glb_map.sol = NULL;
   destroy_min(glb_map.min);
   glb_map.min = NULL;
   destroy_cel_file(glb_map.cel);
   glb_map.cel = NULL;
   destroy_cel_file(glb_map.scel);
   glb_map.scel = NULL;
   destroy_amp(glb_map.amp);
   glb_map.amp = NULL;
}

void pal_d2_2_vga(void) {
   unsigned char r, g, b;
   int   i;

   for (i=0; i<256; i++) {
      r = pal[i][0];
      g = pal[i][1];
      b = pal[i][2];
      r = gamma_table[cur_gamma][r];
      g = gamma_table[cur_gamma][g];
      b = gamma_table[cur_gamma][b];
      the_pal[i].r = r >> 2;
      the_pal[i].g = g >> 2;
      the_pal[i].b = b >> 2;
   }   
}

int blit_cel_image(BITMAP *dest, long int dx, long int dy) {
   unsigned char tt;
   long int i, j;

   if (dest == NULL) {
      fprintf(stderr, "dest == NULL\n");
      return 1;
   }
   for (i = 0; i < 32; ++i) {
      for (j = 0; j < 32; ++j) {
         tt = cel_image_data[i + 32 * j];
         if (tt != 0) {
            putpixel(dest, dx + i, dy + j, tt);
         }
      }
   }
   return 0;
}

int decode_tile_0(CEL *cel) {
   int x, y, i;

   i = 0;
   for (y = 31; y >= 0; --y)
      for (x = 0; x < 32; ++x)
         cel_image_data[x + 32 * y] = cel->data[i++];
   return 1;
}

int decode_tile_1(CEL *cel) {
   int x, y, nb_pix, i, j;

   i = 0;
   x = 0;
   y = 31;
   while (y >= 0) {
      if (i >= cel->size) {
         fprintf(stderr, "too few data for cel (type 1) a !\n");
         return 0;
      }
      if (cel->data[i] >= 0x80) {
         nb_pix = 0x100 - cel->data[i];
         x += nb_pix;
         ++i;
      }
      else {
         if (i >= cel->size) {
            fprintf(stderr, "too few data for cel (type 1) b !\n");
            return 0;
         }
         nb_pix = cel->data[i++];
         for (j = 0; j < nb_pix; ++j) {
            if (i >= cel->size) {
               fprintf(stderr, "too few data for cel (type 1) c !\n");
               return 0;
            }
            cel_image_data[x++ + 32 * y] = cel->data[i++];
            if (x > 31) {
               x = 0;
               --y;
            }
         }
      }
      if (x > 31) {
         x = 0;
         --y;
      }
   }
   return 1;
}

int decode_tile_2(CEL *cel) {
   long int i, x, y;
   int line_size[32] = { 0, 4, 4, 8, 8, 12, 12, 16, 16, 20, 20, 24, 24, 28, 28, 32, 32, 32, 28, 28, 24, 24, 20, 20, 16, 16, 12, 12, 8, 8, 4, 4 };

   i = 0;
   for (y = 31; y >= 0; --y) {
      for (x = 32 - line_size[y]; x < 32; ++x) {
         cel_image_data[x + 32 * y] = cel->data[i++];
      }
   }
   return 1;
}

int decode_tile_3(CEL *cel) {
   int i, x, y;
   const int line_size[32] = { 0, 4, 4, 8, 8, 12, 12, 16, 16, 20, 20, 24, 24, 28, 28, 32, 32, 32, 28, 28, 24, 24, 20, 20, 16, 16, 12, 12, 8, 8, 4, 4 };

   i = 0;
   for (y = 31; y >= 0; --y) {
      for (x = 0; x < line_size[y]; ++x) {
         cel_image_data[x + 32 * y] = cel->data[i++];
      }
   }
   return 1;
}

int decode_tile_4(CEL *cel) {
   long int i, x, y;
   const int line_size[32] = { 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32 , 28, 28, 24, 24, 20, 20, 16, 16, 12, 12, 8, 8, 4, 4 };

   i = 0;
   for (y = 31; y >= 0; --y) {
      for (x = 32 - line_size[y]; x < 32; ++x) {
         cel_image_data[x + 32 * y] = cel->data[i++];
      }
   }
   return 1;
}

int decode_tile_5(CEL *cel) {
   long int i, x, y;
   const int line_size[32] = { 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32, 32 , 28, 28, 24, 24, 20, 20, 16, 16, 12, 12, 8, 8, 4, 4 };

   i = 0;
   for (y = 31; y >= 0; --y) {
      for (x = 0; x < line_size[y]; ++x) {
         cel_image_data[x + 32 * y] = cel->data[i++];
      }
   }
   return 1;
}

int put_cel(BITMAP *bmp, int cel, int type, int x, int y) {
   int res;

   if (glb_map.cel == NULL)
      return 1;
   if ((cel < 0) ||(cel >= glb_map.cel->nb)) {
      fprintf(stderr, "bad cel index : 0x%X\n", cel);
      return 1;
   }
   memset(cel_image_data, 0, 0x400);
   switch (type) {
      case 0 :
         res = decode_tile_0(glb_map.cel->frame + cel);
         break;
      case 1 :
         res = decode_tile_1(glb_map.cel->frame + cel);
         break;
      case 2 :
         res = decode_tile_2(glb_map.cel->frame + cel);
         break;
      case 3 :
         res = decode_tile_3(glb_map.cel->frame + cel);
         break;
      case 4 :
         res = decode_tile_4(glb_map.cel->frame + cel);
         break;
      case 5 :
         res = decode_tile_5(glb_map.cel->frame + cel);
         break;
      default :
         fprintf(stderr, "unknown tile type : %d\n", type);
         return 1;
   }
   if (res == 0) {
      fprintf(stderr, "probleme with cel 0x%X (type %d)\n", cel, type);
      return 1;
   }
   blit_cel_image(bmp, x, y);
   return 0;
}

int put_min(BITMAP *bmp, int min, int x, int y) {
   int i, cel_index, cel_type;

   if (glb_map.min == NULL)
      return 1;
   if ((min < 0) || (min > glb_map.min->nb)) {
      fprintf(stderr, "Invalid min index : %d\n", min);
      return 1;
   }
   for (i = 0; i < glb_map.min_size; ++i) {
      cel_index = glb_map.min->data[min * glb_map.min_size + i];
      if (cel_index != 0) {
         cel_type = cel_index >> 12;
         cel_index = (cel_index & 0x0FFF) - 1;
         put_cel(bmp, cel_index, cel_type, (i & 1) ? x + 32 : x, y - 32 * ((glb_map.min_size - i - 1) >> 1));
      }
   }
   return 0;
}

int put_til(BITMAP *bmp, int til, int x, int y) {
   int i, min_index;
   int dx[] = { 0, 32, -32, 0 };
   int dy[] = { 0, 16, 16, 32 };

   if (glb_map.til == NULL)
      return 1;
   for (i = 0; i < 4; ++i) {
      min_index = glb_map.til->data[til][i];
      put_min(bmp, min_index, x + dx[i], y + dy[i]);
   }
   return 0;
}

void read_gamma(void) {
   FILE * in;
   int  gt, i, v;
   char gamma_path[] = "gamma.dat";

   in = fopen(gamma_path, "rb");
   if (in == NULL) {
      printf("can't read %s\n", gamma_path);
      exit(1);
   }
   for (gt=GC_060; gt < GC_MAX; gt++) {
      for (i=0; i<256; i++) {
         v = fgetc(in);
         gamma_table[gt][i] = v;
      }
   }
   fclose(in);
}

void dt1debug_exit(void) {
   free_map();
}

int load_palette(char * name) {
   int  i, j;
   unsigned char *buff;
   long int size;
   
   misc_load_mpq_file(name, &buff, &size, 0);
   if (buff == NULL) {
      printf("\ncan't open palette : %s\n", name);
      return 1;
   }
   j = 0;
   for (i = 0; i < 256; i++) {
      pal[i][0] = buff[j++];
      pal[i][1] = buff[j++];
      pal[i][2] = buff[j++];
   }
   pal[0][0] = pal[0][1] = pal[0][2] = 60;
   free(buff);
   return 0;
}

void new_gfx_mode(int x, int y) {
   if (set_gfx_mode(GFX_AUTODETECT, x, y, 0, 0) < 0) { set_gfx_mode(GFX_TEXT, 80, 25, 0, 0); printf("can't initialise the gfx mode %i %i 8 bpp\n", x, y); printf("%s\n", allegro_error); exit(1); }
}

int put_no_header_cel(BITMAP *bmp, CEL *cel, int dx, int dy) {
   unsigned long int i, j, nb_pix;
   long int width, x, y, not_done;

   i = 0;
   width = 0;
   not_done = 1;
   while (not_done) {
      if (i >= cel->size) {
         return 1;
      }
      if (cel->data[i] == 0x7F) {
         width += cel->data[0];
         i += 0x7F;
      }
      else {
         if (cel->data[i] >= 0x80)
            width += 0x100 - cel->data[i];
         else
            width += cel->data[i];
         not_done = 0;
      }
   }
   i = 0;
   x = 0;
   y = -1;
   while (i < cel->size) {
      if (cel->data[i] >= 0x80) {
         nb_pix = 0x100 - cel->data[i];
         x += nb_pix;
         ++i;
      }
      else {
         nb_pix = cel->data[i++];
         for (j = 0; j < nb_pix; ++j) {
            putpixel(bmp, dx + x++, dy + y, cel->data[i++]);
         }
      }
      if (x >= width) {
         x = 0;
         --y;
      }
   }
   return 0;
}

int put_header_cel(BITMAP *bmp, CEL *cel, int dx, int dy) {
   unsigned long int i, j, nb_pix;
   long int width, height, x, y;
   unsigned short int offset[5];

   for (i = 0; i < 5; ++i)
      offset[i] = *((unsigned short int *)(cel->data + 2 * i));
   if (offset[0] != 10) {
      put_no_header_cel(bmp, cel, dx, dy);
      return 1;
   }
   width = 0;
   for (i = offset[0]; i < offset[1]; ++i) {
      if (cel->data[i] >= 0x80)
         width += 0x100 - cel->data[i];
      else {
         width += cel->data[i];
         i += cel->data[i];
      }
   }
   if (i != offset[1]) {
      fprintf(stderr, "offset 1 non valable\n");
      return 1;
   }
   if (width & 31) {
      fprintf(stderr, "bad number of pixels for 0x20 lines\n");
      return 1;
   }
   width >>= 5;
   height = 0;
   for (i = 0; i < 5; ++i)
      if (offset[i] != 0)
         height += 32;
   i = 10;
   x = 0;
   y = -1;
   while (i < cel->size) {
      if (cel->data[i] >= 0x80) {
         nb_pix = 0x100 - cel->data[i];
         x += nb_pix;
         ++i;
      }
      else {
         nb_pix = cel->data[i++];
         for (j = 0; j < nb_pix; ++j) {
            putpixel(bmp, dx + x++, dy + y, cel->data[i++]);
         }
      }
      if (x >= width) {
         x = 0;
         --y;
      }
   }
   return 0;
}

char *change_curr_palette(int act, int curr_pal) {
   char tmp[300];

   sprintf(tmp, "%s\\%s", path[act], palname[act][curr_pal]);
   load_palette(tmp);
   pal_d2_2_vga();
   set_palette(the_pal);
   return palname[act][curr_pal];
}

int main(int argc, char * argv[]) {
   long       tile_index, scel_index_left, scel_index_right;
   char       tmp[80];
   int        k, done = FALSE, scr=0, plotx=150, ploty=400, act,
              screen_x = 640, screen_y = 480;
   BITMAP     * tmpbmp;
   char *pal_name, *lvl_name;
   FILE *in;
   int c, mpq_num = 0, strcount = 0;

   printf("Tile Viewer, Based on Paul Siramy's source\n"
          "Have a look at http://paul.siramy.free.fr/\n"
          "==========================================\n");
   in = NULL;
   k = 0;
   if (argc > 2) {
      while((mod_dir[0][k] = argv[2][k]) != '\0')
         ++k;
      if (mod_dir[0][k - 1] == '\\')
         mod_dir[0][k - 1] = '\0';
   }
   if (argc > 1)
      fopen(argv[1], "rt");
   if (in != NULL){
     while (((c = fgetc(in))!=EOF) && (mpq_num < MAX_MPQ_FILE)) {
       if ((c == '\n') || (c == '\0') || (c == 0x0A) || (c == 0x0D)) {
         if(strcount > 0) {
           ++mpq_num;
           mpq_file[mpq_num][strcount] = '\0';
           strcount = 0;
         }
       }
       else {
         mpq_file[mpq_num][strcount] = c;
         ++strcount;
       }
     }
     mpq_file[mpq_num][strcount] = '\0';
     fclose(in);
   }
   mpq_lib_start();

   act = 1;
   pal_name = change_curr_palette(act, 0);
   read_gamma();
   pal_d2_2_vga();
   lvl_name = init_map(act);
   allegro_init();
   set_color_depth(8);
   atexit(dt1debug_exit);
   install_keyboard();
   new_gfx_mode(screen_x, screen_y);
   set_palette(the_pal);
   tile_index = 0;
   tmpbmp = create_bitmap(screen_x, screen_y);
   scel_index_left = -1;
   scel_index_right = -1;
   while ( ! done) {
      clear(tmpbmp);
      ploty = screen_y - 160;
      put_til(tmpbmp, tile_index, plotx, ploty);
      if (scel_index_left != -1) {
         if ((act == 0) || (act == 7) || (act == 2)) {
            put_header_cel(tmpbmp, glb_map.scel->frame + scel_index_left, plotx, ploty + 32);
         }
         else {
            put_header_cel(tmpbmp, glb_map.scel->frame + scel_index_left, plotx - 32, ploty + 48);
         }
      }
      if (scel_index_right != -1) {
         put_header_cel(tmpbmp, glb_map.scel->frame + scel_index_right, plotx + 32, ploty + 48);
      }
      sprintf(tmp, "PATH : %s", path[act]);
      textout(tmpbmp, font, tmp, 10, 10, 255);
      if (glb_map.til != NULL) {
         sprintf(tmp, "tile %lu on %d", tile_index, glb_map.til->nb - 1);
         textout(tmpbmp, font, tmp, 10, 20, 255);
      }
      sprintf(tmp, "palette : %s (gamma %s) ", pal_name, gamma_str[cur_gamma]);
      textout(tmpbmp, font, tmp, 10, 30, 255);
      if (glb_map.scel != NULL) {
         if ((act == 0) || (act == 7) || (act == 2)) {
            sprintf(tmp, "%ss.cel : %ld/%lu", lvl_name, scel_index_left, glb_map.scel->nb);
            textout(tmpbmp, font, tmp, 10, 40, 255);
         }
         else {
            sprintf(tmp, "%ss.cel : %ld/%lu  %ld/%lu", lvl_name, scel_index_left, glb_map.scel->nb, scel_index_right, glb_map.scel->nb);
            textout(tmpbmp, font, tmp, 10, 40, 255);
         }
      }
      if ((glb_map.til != NULL) && (glb_map.sol != NULL)) {
         if (glb_map.amp != NULL) {
            sprintf(tmp, "%s.amp : %04X", lvl_name, glb_map.amp->data[tile_index]);
            textout(tmpbmp, font, tmp, 324, 10, 255);
            sprintf(tmp, "Orientation : %02X", glb_map.amp->data[tile_index] & 0x00FF);
            textout(tmpbmp, font, tmp, 324, 20, 255);
            if (glb_map.amp->data[tile_index] & 0x0100)
               textout(tmpbmp, font, "Door (left)", 324, 30, 255);         
            if (glb_map.amp->data[tile_index] & 0x0200)
               textout(tmpbmp, font, "Door (right)", 324, 40, 255);
            if (glb_map.amp->data[tile_index] & 0x0400)
               textout(tmpbmp, font, "Arch (left)", 324, 50, 255);
            if (glb_map.amp->data[tile_index] & 0x0800)
               textout(tmpbmp, font, "Arch (right)", 324, 60, 255);
            if (glb_map.amp->data[tile_index] & 0x1000)
               textout(tmpbmp, font, "Grill (left)", 324, 70, 255);
            if (glb_map.amp->data[tile_index] & 0x2000)
               textout(tmpbmp, font, "Grill (right)", 324, 80, 255);
            if (glb_map.amp->data[tile_index] & 0x4000)
               textout(tmpbmp, font, "Roof", 324, 90, 255);
            if (glb_map.amp->data[tile_index] & 0x8000)
               textout(tmpbmp, font, "Stairs", 324, 100, 255);
         }
         sprintf(tmp, "FloorFlag :       %02X", glb_map.sol->data[glb_map.til->data[tile_index][0]]);
         textout(tmpbmp, font, tmp, 324, 180, 255);
         sprintf(tmp, "               %02X    %02X", glb_map.sol->data[glb_map.til->data[tile_index][2]], glb_map.sol->data[glb_map.til->data[tile_index][1]]);
         textout(tmpbmp, font, tmp, 324, 190, 255);
         sprintf(tmp, "                  %02X", glb_map.sol->data[glb_map.til->data[tile_index][3]]);
         textout(tmpbmp, font, tmp, 324, 200, 255);
      }
      textout(tmpbmp, font, "F12 / Shift + F12 = gamma correction",    324, 260, 255);
      textout(tmpbmp, font, "'Esc' = quit",                            324, 280, 255);
      textout(tmpbmp, font, "'B'   = change boxsize mode",             324, 290, 255);
      textout(tmpbmp, font, "'G'   = change grid mode",                324, 300, 255);
      textout(tmpbmp, font, "'L'   = layer vs grid priority",          324, 310, 255);
      textout(tmpbmp, font, "'P'   = print screen (screenshot)",       324, 320, 255);
      textout(tmpbmp, font, "move  : Up / Down / Left / Right / ",     324, 330, 255);
      textout(tmpbmp, font, "        Page Up / Page Down /",           324, 340, 255);
      textout(tmpbmp, font, "        Backspace / Home / End",          324, 350, 255);
      textout(tmpbmp, font, "'F1'..'F7'  = Change area",               324, 360, 255);
      textout(tmpbmp, font, "'1'..'6'  = palette 1..6",                324, 370, 255);
      textout(tmpbmp, font, "'AZERQSDFW' = change SCEL",               324, 380, 255);
      textout(tmpbmp, font, "'TYUIGHJKB' = change SCEL",               324, 390, 255);
      textout(tmpbmp, font, "Space       = remove SCELs",              324, 400, 255);
      textout(tmpbmp, font, "'+' (keypad) = higher screen resolution", 324, 410, 255);
      textout(tmpbmp, font, "'-' (keypad) = lower screen resolution",  324, 420, 255);
      sprintf(tmp, "current resolution : %i * %i", screen_x, screen_y);
      textout(tmpbmp, font, tmp,                                       324, 440, 255);
      textout(tmpbmp, font, "Diablo Tile Viewer, Based on Paul Siramy's source", 10, 450, 255);
      textout(tmpbmp, font, "Have a look at http://paul.siramy.free.fr/", 10, 460, 255);
      vsync();
      blit(tmpbmp, screen, 0, 0, 0, 0, screen_x, screen_y);
      k = readkey();
      switch(k >> 8) {
         case KEY_ESC :
            done = TRUE; break;
         case KEY_RIGHT :
         case KEY_UP : 
            if (glb_map.til == NULL)
               break;
            if (tile_index < glb_map.til->nb - 1)
               ++tile_index;
            break;
         case KEY_PGUP :
            if (glb_map.til == NULL)
               break;
            if (tile_index < glb_map.til->nb - 11)
               tile_index += 10;
            else
               tile_index = glb_map.til->nb - 1;
            break;
         case KEY_PGDN :
            if (glb_map.til == NULL)
               break;
            if (tile_index > 10)
               tile_index -= 10;
            else
               tile_index = 0;
            break;
         case KEY_LEFT :
         case KEY_DOWN :
         case KEY_BACKSPACE :
            if (glb_map.til == NULL)
               break;
            if (tile_index > 0)
               --tile_index;
            break;
         case KEY_HOME :
            if (glb_map.til == NULL)
               break;
            tile_index=0;
            break;
         case KEY_END :
            if (glb_map.til == NULL)
               break;
            tile_index=glb_map.til->nb - 1;
            break;
         case KEY_1 :
            pal_name = change_curr_palette(act, 0);
            break;
         case KEY_2 :
            pal_name = change_curr_palette(act, 1);
            break;
         case KEY_3 :
            pal_name = change_curr_palette(act, 2);
            break;
         case KEY_4 :
            pal_name = change_curr_palette(act, 3);
            break;
         case KEY_5 :
            pal_name = change_curr_palette(act, 4);
            break;
         case KEY_6 :
            pal_name = change_curr_palette(act, 5);
            break;
         case KEY_P :
            sprintf(tmp, "screenshot-%05i.pcx", scr);
            while (file_exists(tmp, -1, NULL)) {
               scr++;
               sprintf(tmp, "screenshot-%05i.pcx", scr);
            }
            save_pcx(tmp, tmpbmp, the_pal);
            scr++;
            break;
         case KEY_MINUS_PAD :
            switch(screen_x) {
               case 640  : break;
               case 800  : screen_x = 640;  screen_y = 480; break;
               case 1024 : screen_x = 800;  screen_y = 600; break;
               case 1280 : screen_x = 1024; screen_y = 768; break;
            }
            new_gfx_mode(screen_x, screen_y);
            set_palette(the_pal);
            destroy_bitmap(tmpbmp);
            tmpbmp = create_bitmap(screen_x, screen_y);
            break;
         case KEY_PLUS_PAD :
            switch(screen_x) {
               case 640  : screen_x = 800;  screen_y = 600;  break;
               case 800  : screen_x = 1024; screen_y = 768;  break;
               case 1024 : screen_x = 1280; screen_y = 1024; break;
               case 1280 : break;
            }
            new_gfx_mode(screen_x, screen_y);
            set_palette(the_pal);
            destroy_bitmap(tmpbmp);
            tmpbmp = create_bitmap(screen_x, screen_y);
            break;
         case KEY_F12 :
            if (key[KEY_LSHIFT] || key[KEY_RSHIFT]) {
               if (cur_gamma > GC_060)
                  cur_gamma--;
            }
            else {
               if (cur_gamma < GC_300)
                  cur_gamma++;
            }
            pal_d2_2_vga();
            set_palette(the_pal);
            break;
         case KEY_SPACE :
            scel_index_left = -1;
            scel_index_right = -1;
            break;
         case KEY_Z :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 16)
                  scel_index_left = 16;
               break;
            }
            scel_index_left = -1;
            break;
         case KEY_Q :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 0)
                  scel_index_left = 0;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 0)
                  scel_index_left = 0;
            break;
         case KEY_W :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 1)
                  scel_index_left = 1;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 1)
                  scel_index_left = 1;
            break;
         case KEY_E :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 2)
                  scel_index_left = 2;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 2)
                  scel_index_left = 2;
            break;
         case KEY_R :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 3)
                  scel_index_left = 3;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 3)
                  scel_index_left = 3;
            break;
         case KEY_A :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 8)
                  scel_index_left = 8;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 4)
                  scel_index_left = 4;
            break;
         case KEY_S :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 9)
                  scel_index_left = 9;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 5)
                  scel_index_left = 5;
            break;
         case KEY_D :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 10)
                  scel_index_left = 10;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 6)
                  scel_index_left = 6;
            break;
         case KEY_F :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 11)
                  scel_index_left = 11;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 7)
                  scel_index_left = 7;
            break;
         case KEY_B :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 17)
                  scel_index_left = 17;
               break;
            }
            scel_index_right = -1;
            break;
         case KEY_T :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 4)
                  scel_index_left = 4;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 0)
                  scel_index_right = 0;
            break;
         case KEY_Y :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 5)
                  scel_index_left = 5;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 1)
                  scel_index_right = 1;
            break;
         case KEY_U :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 6)
                  scel_index_left = 6;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 2)
                  scel_index_right = 2;
            break;
         case KEY_I :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 7)
                  scel_index_left = 7;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 3)
                  scel_index_right = 3;
            break;
         case KEY_G :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 12)
                  scel_index_left = 12;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 4)
                  scel_index_right = 4;
            break;
         case KEY_H :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 13)
                  scel_index_left = 13;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 5)
                  scel_index_right = 5;
            break;
         case KEY_J :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 14)
                  scel_index_left = 14;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 6)
                  scel_index_right = 6;
            break;
         case KEY_K :
            if ((act == 0) || (act == 7) || (act == 2)) {
               if (glb_map.scel->nb > 15)
                  scel_index_left = 15;
               break;
            }
            if (glb_map.scel != NULL)
               if (glb_map.scel->nb > 7)
                  scel_index_right = 7;
            break;
         case KEY_F1 :
            act = 1;
            free_map();
            scel_index_left = -1;
            scel_index_right = -1;
            lvl_name = init_map(act);
            tile_index = 0;
            pal_name = change_curr_palette(act, 0);
            break;
         case KEY_F2 :
            act = 2;
            free_map();
            scel_index_left = -1;
            scel_index_right = -1;
            lvl_name = init_map(act);
            tile_index = 0;
            pal_name = change_curr_palette(act, 0);
            break;
         case KEY_F3 :
            act = 3;
            free_map();
            scel_index_left = -1;
            scel_index_right = -1;
            lvl_name = init_map(act);
            tile_index = 0;
            pal_name = change_curr_palette(act, 0);
            break;
         case KEY_F4 :
            act = 4;
            free_map();
            scel_index_left = -1;
            scel_index_right = -1;
            lvl_name = init_map(act);
            tile_index = 0;
            pal_name = change_curr_palette(act, 0);
            break;
         case KEY_F5 :
            act = 5;
            free_map();
            scel_index_left = -1;
            scel_index_right = -1;
            lvl_name = init_map(act);
            tile_index = 0;
            pal_name = change_curr_palette(act, 0);
            break;
         case KEY_F6 :
            act = 6;
            free_map();
            scel_index_left = -1;
            scel_index_right = -1;
            lvl_name = init_map(act);
            tile_index = 0;
            pal_name = change_curr_palette(act, 0);
            break;
         case KEY_F7 :
            act = 0;
            free_map();
            scel_index_left = -1;
            scel_index_right = -1;
            lvl_name = init_map(act);
            tile_index = 0;
            pal_name = change_curr_palette(act, 0);
            break;
      }
   }
   destroy_bitmap(tmpbmp);
   mpq_lib_stop();
   return 0;
}
END_OF_MAIN()
