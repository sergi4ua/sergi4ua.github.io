This tile viewer for Diablo/Hellfire is based on the DT1 tools for Diablo2 written by Paul Siramy. MPQ management are mainly Jarulf's routines.

Usage should be straightforward, all keys are listed to screen.
You must have allegro library to use this program.

By default, the program will search files in :
*in c:\program files\diablo\ (for example : c:\program files\diablo\levels\towndata\town.pal)
*if not found, then in c:\program files\diablo\patch_rt.mpq 
*if not found, then in c:\program files\diablo\hellfire.mpq 
*if not found, then in c:\program files\diablo\hfmonk.mpq (not really useful...)
*if not found, then in c:\program files\diablo\diabdat.mpq

The mpq files to look in may be changed by giving a text file with their path/names. You can use up to 6 MPQ files. Exemple :
ViewTile.exe Ulmo.ini

And the directory can be changed by giving a third argument :
ViewTile.exe Ulmo.ini c:\MyFolder
