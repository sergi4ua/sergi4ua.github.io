------------------------DONT TOUCH---------------------
function printMsg(data)
     if type(data) == "string" then
	     printMessage(data)
	else
	    --printMessage("wrong data for printMsg function - input wasn't a string!")
		printMessage(tostring(data))
	end
end

TRUE = 1
FALSE = 0

--possible data.textColor values
COLOR_WHITE = 0 
COLOR_RED = 2
COLOR_BLUE = 3
COLOR_GOLD = 4
COLOR_GREY = 5
COLOR_YELLOW = 6
COLOR_ORANGE = 7
COLOR_GREEN = 8

--possible data.itemType values
ITEM_MISC = 0   --quest items
ITEM_POTION = 1 -- potions and elixirs
ITEM_SCROLL = 2 -- scrolls
ITEM_BOOK = 3	-- books
ITEM_GOLD = 4   -- gold
ITEM_FING = 5   -- rings etc.
ITEM_NECK = 6   -- amulets etc.
ITEM_HEAD = 7   -- helmets
ITEM_BODY = 8   -- armors
ITEM_SHIELD = 9 -- shields
ITEM_WP_1H = 10  -- one-handed weapons
ITEM_WP_2H = 11  -- two-handed weapons
ITEM_WAIST = 12 -- belts
ITEM_WP_OFFHAND = 13  -- offhand weapons
ITEM_CRAFTINGMAT = 14  -- crafting materials
ITEM_RECIPE = 15  -- recipes

function lootFilter(displayedName,textColor,itemType)
	local isGood,v1 = pcall(myLootFilter,{displayedName=displayedName:lower(),textColor=textColor,itemType=itemType})
    if isGood == true then
		if v1 ~= nil then
		    if type(v1) == "number" then
				if 1==1 then
				    return v1
				else
					printMsg("The number values for loot filter must be between 0 and 255.")
				end
			else
				printMsg("Your loot filter returned bad values!")	
			end
		else
		    printMsg("One or more of the values returned by your lootFilter were empty!!!")	
		end
	else
		printMsg(ret)
	end
	return TRUE
end

--[[
If you edit this script while the game is running, tap V twice to reload it.
Tapping V once will disable loot filters.
Loot filter script is active by default.

You can find out more about LUA here
https://www.tutorialspoint.com/lua/
HOW TO ADD YOUR OWN FILTER? 
https://www.tutorialspoint.com/lua/lua_functions.htm
You need to create a function.
If an item is supposed to be hidden, the function has to return "true".
Anything else than "true" will cause the item to be visible.
Example of a function:

function hideWhiteEquipment(data)
    if data.textColor == COLOR_WHITE and isEquipment(data) == true then
		return true
	end
end
    --]]
	--[[
We are checking if text color is white and if it's something we can equip 
I've created the function isEquipment above,
feel free to create your own helping functions when you learn more about LUA
and share your loot filters on the "loot-filter-scripts" channel on Discord!


So you got a function. Now how to make it work?
You have to add it to filterList array in myLootFilter function (bottom of the file)

As you can see, the main loot filter function has the following parameters:
lootFilter(displayedName,textColor,itemType)
so if you pass "data" to it in myLootFilter function, you can access these variables by writing
data.displayedName / data.textColor / data.itemType

Different functions in filterList should be separated by a comma.
We should pass data to the function.
So the thing we should add to the filterList to make our new function work would be
hideWhiteEquipment(data)

Be careful about hiding more items that you want.
For example, if you wanted to hide all white items but wanted to see the scrolls, you'd have to check if the color is white and return "false" if the item is a scroll.
Hiding ALL white items would be a bad idea, as you'd never see gold/scrolls/books etc. 
That's why I'm checking if the item can b equipped - that way I don't have to worry about books/scrolls/potions...

I've created two loot filters that are disabled by default.
To enable them, uncomment the two lines in myLootFilter (comment = --)

    --]]
	
function isGold(data)
	return data.itemType == ITEM_GOLD
end

function isEquipment(data)
	return data.itemType >= ITEM_FING and data.itemType <= ITEM_WP_OFFHAND
end

function hideEquipment(data,color)
    if data.textColor == color and isEquipment(data) == true then
		return true
	end
end

function hideGoldBelow(data,howmuch)
	if isGold(data) == true then
		howMuchGold = tonumber(string.match(string.match(data.displayedName,"%d+ gold pieces"),"%d+"))
		if howMuchGold >= howmuch then
			return false
		else
			return true
		end
	end
	return false
end

---------------ADD YOUR OWN LOOT FILTERS BELOW THIS LINE-----------------------------
--WHEN SHARING THEM ON DISCORD, DON'T SHARE THE WHOLE FILE (NO NEED), JUST YOUR LOOT FUNCTION AND filterList

function myLootFilter(data)
---------------add your functions to the array here!---------------
	filterList = {
	--hideGoldBelow(data,2500),       -- hides gold piles with less than X pieces
	--hideEquipment(data,COLOR_WHITE),-- hides white items
	--hideEquipment(data,COLOR_BLUE)  -- hides magic items
	}
---------------end of functions array, don't touch the rest!---------------
	for i= 1, #filterList do
		if filterList[i] == true then
			return FALSE
		end
	end
	return TRUE
end

