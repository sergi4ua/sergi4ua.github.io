##############################
#                            #
# Retribution v1.2 (3/24/99) #
#                            #
##############################

Created by Ared Mosinel, aka Charlie on AGD.

There are numerous modifications made in this mod, and I will try to list them all here.  Please refer to the dataretr.txt file for statistical information.

First and foremost, this mod uses a different file save format than regular Diablo.  Single Player saves will be named "retsp_#.sv" and will be found in the same directory as the Retribution.exe.  Multi Player saves will be named "retmp_#.drv" and will be found in the C:\Windows directory.

If you HAVE to rename a current character to play the mod (which is cheating IMO), your items may morph.


Prefix / Suffix Changes
=======================
Nothing was done to the actual values of the prefix/suffixes.  Some can appear on different items than before.  The biggest change is that EVERY one of them can now be found in the dungeon or for sale.

Unique Item Changes
===================
Quite a few unique items have been changed, but not all of them.  A "superweapon" exists for all 3 classes, but they can only be found in L16.

Characters Changes
==================
Each character class has a stat that can be 5 points higher to max out..big whoop...hehehe.  The Rogue's starting bow does one extra point of damage and the Sorcerer's staff casts Holy Bolts instead of Charged Bolts.  The Warrior has a funny little speech he says when his inventory is full..hehe.

Base Item Changes
=================
Hardly anything was done to the base items.  I created a new "mega elixir" type that does what the Spectral Elixir does in SP, but it shows up as a mid class armor on the ground.  Dunno why...hehe.  Elixirs of Vitality can be bought as well.

Spell Changes
=============
Made some magic changes....enabled Apocalypse, Nova, Identify, and Etherealize to be learnable spells.  Some may not appear in the spell book, but who cares??  You have the spell and that is what matters.

Monster Changes
===============
Woohoo!  I had a lot of fun playing around here..hehe.  Almost all the monsters are smarter than before...from imps opening doors to skeleton archers chasing you down...and the Butcher actually having a brain.  Beware the Skeleton King..he's not as dead as you may think  ;)  I created a few monsters of my own as well.

Boss Monster Changes
====================
This may not be too evident at first, but all boss monsters' HP will be around one hundred times that of the dungeon level you find them on..give or take 50 HP.  So a boss you find on level 13 will have around 1250-1350 HP.  Yall wanted harder boss monsters...you got them..hehe.  Some bosses will ALWAYS appear in the game...specifically in levels 4, 8, 12, and 16.  Think of them as the bosses of that particular area of the game.


I had Gharbad the Weak and Zhar the Mad enabled for multiplayer, but...get this...some people actually COMPLAINED about them always giving items and books away when you go to town after first receiving the free gift.  So, I had them removed.  Lazarus' room in MP will not have the altar with the boy...don't know why it is missing.
The mod has various other features, such as the ability to equip two weapons or shields (do the latter at your own risk), casting Blood Star and Bone Spirit without the life drain feature, and others I can't recall off the top of my head.  I hope everyone likes the mod and has a fun time playing it!



Ared Mosinel
vrahvinv@bellsouth.net