"Belzebub" is the code name of a modification project, which will probably be the most advanced Diablo 1 mod. For now the project is in open beta phase (single player). 


Installation:

In order to run mod, copy all files from archive to Diablo 1 game folder. Modification requires openAL library installed which is included in the archive. To start game run Belzebub.exe file. Remember that mod requires mounted Diablo 1 cd in virtual drive or diabdat.mpq copied to it's root folder. 


Minimal system requirements:

OS: Windows XP or newer 
CPU: 1.0 Ghz 
RAM: 1 GB 
Graphics: 256 RAM, with support of openGl 1.5 or greater 
Free disc space: 100 MB 
Sound: openAL installed 


Additional songs:

Aftermath - Kevin MacLeod (incompetech.com)
Controlled Chaos - no percussion - Kevin MacLeod (incompetech.com)
Forest of Lights - Noktis


More at:
http://mod.diablo1.eu.org/
https://www.facebook.com/Diablo1ModAwakening


Reporting bugs:

Bugs should be reported on forums on http://mod.diablo1.eu.org/

