UMXPlayer was created by Sergi4UA. Using the BASSMOD library (https://www.un4seen.com/bassmod.html) for music playback.
Supported games: Unreal Gold, Deus Ex, Unreal Tournament, Rune
The software is licensed under CC BY-NC 3.0 (https://creativecommons.org/licenses/by-nc/3.0/)

Version: 1.1

Website:
https://sergi4ua.com
https://sergi4ua.com/apps/umxplayer